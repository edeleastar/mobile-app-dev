
import models.Division;
import play.jobs.*;
import play.test.*;
 
@OnApplicationStart
public class Bootstrap extends Job<Object> 
{ 
  public void doJob()
  {
    if (Division.count() == 0)
    {
      //Fixtures.loadModels("data.yml");
    }
  }
}