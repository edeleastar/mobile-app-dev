package controllers;

import java.util.List;

import models.Player;
import play.mvc.Controller;
import java.util.List;
import models.Club;
import play.Logger;

public class PlayersController extends Controller
{      
  public static void index()
  {
    List<Player> players = Player.findAll();
    render (players);
  }
  
  public static void delete(Long id)
  {
    Player player = Player.findById(id);
    if (player != null)
    {
      player.club.removePlayer(player);
      player.club.save();
      player.delete();
    }
    index();
  }
  
  public static void newPlayer()
  {
    List<Club> clubs = Club.findAll();
    render(clubs);
  }
  
  public static void createPlayer(String name, String club)
  {
    Logger.info("Name: " + name + ": Club: " + club);
    
    Player player = new Player (name);
    Club theClub = Club.findByName(club);
    if (theClub != null)
    {
      theClub.addPlayer(player);
      theClub.save();
    }
    index();
  }
  
  public static void changePlayer(Long id, String name, Long club)
  {
    Player player = Player.findById(id);
    if (player != null)
    {
      player.name = name;
      Club theClub = Club.findById(club);
      player.club = theClub;
      player.save();
    }
    index();
  }
  
  public static void editPlayer(Long id)
  {
    Player player = Player.findById(id);
    List<Club> clubs = Club.findAll();
    Integer clubIndex = clubs.indexOf(player.club);
    clubIndex++;
    render(player, clubs, clubIndex);
  }  
}
