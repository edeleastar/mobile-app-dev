package controllers;

import play.*;
import play.mvc.*;
import utils.JsonParsers;

import java.util.*;

import models.*;

public class CoffeeServiceAPI extends Controller
{
  public static void getCoffees()
  {
    List<Coffee> coffees = Coffee.findAll();
    renderText(coffees.get(0));
  }
  
  public static void coffee (Long id)
  {
   Coffee coffee = Coffee.findById(id);
   renderJSON (JsonParsers.coffee2Json(coffee));
  }
}
