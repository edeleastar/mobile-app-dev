package test;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;
import ie.cm.api.Coffee;
import ie.cm.api.CoffeeAPI;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class CoffeeTest
{
  private Coffee mocha;
  private long   mochaId;
  
  @Before
  public void setup() throws Exception
  {
    Coffee returnedCoffee;
    
    mocha     = new Coffee ("mocha",     "costa",  4.5, 3.0, 1);
    returnedCoffee = CoffeeAPI.createCoffee(mocha);
    mochaId = returnedCoffee.id;
  }
  
  @After
  public void teardown()
  {
    mocha     = null; 
  }
  
  @Test
  public void testCreateCoffee () throws Exception
  {
    assertEquals (mocha, CoffeeAPI.getCoffee(mochaId));
  }
}
