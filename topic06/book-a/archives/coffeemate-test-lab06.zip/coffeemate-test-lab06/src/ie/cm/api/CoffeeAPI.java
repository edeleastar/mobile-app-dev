package ie.cm.api;

import java.util.List;

public class CoffeeAPI
{  
  public static Coffee getCoffee (Long id) throws Exception
  {
    String coffeeStr = Rest.get("/api/coffees/" + id);
    Coffee coffee = JsonParsers.json2Coffee(coffeeStr);
    return coffee;
  }
  
  public static Coffee createCoffee(String coffeeJson) throws Exception
  {
    String response = Rest.post ("/api/coffees", coffeeJson);
    return JsonParsers.json2Coffee(response);
  }
  
  public static Coffee createCoffee(Coffee coffee) throws Exception
  {
    return createCoffee(JsonParsers.coffee2Json(coffee));
  }

  public static List<Coffee> getCoffees () throws Exception
  {
    String response =  Rest.get("/api/coffees");
    List<Coffee> coffeeList = JsonParsers.json2Coffees(response);
    return coffeeList;
  } 
}
