import org.junit.*;
import java.util.*;
import play.test.*;
import models.*;

public class CoffeeTest extends UnitTest
{
  @Test
  public void testCreate()
  {
    Coffee coffee = new Coffee ("one", "here", 3.5, 2.0, 0);
    coffee.save();
    Coffee one = Coffee.findById(coffee.id);
    assertEquals (coffee, one);
  }
}
