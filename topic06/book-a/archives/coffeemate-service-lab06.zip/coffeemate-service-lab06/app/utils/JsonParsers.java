package utils;

import java.lang.reflect.Type;
import java.util.List;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import models.Coffee;

public class JsonParsers
{
  static Gson gson = new Gson();
  
  public static String user2Json(Object obj)
  {
    return gson.toJson(obj);
  }  
 
  public static Coffee json2Coffee(String json)
  {
    return gson.fromJson(json, Coffee.class);    
  }
  
  public static String coffee2Json(Object obj)
  {
    return gson.toJson(obj);
  }  
  
  public static List<Coffee> json2Coffees(String json)
  {
    Type collectionType = new TypeToken<List<Coffee>>() {}.getType();
    return gson.fromJson(json, collectionType);    
  }  
}
