package controllers;

import play.*;
import play.mvc.*;
import utils.JsonParsers;

import java.util.*;

import com.google.gson.JsonElement;

import models.*;

public class CoffeeServiceAPI extends Controller
{
  public static void coffees()
  {
    List<Coffee> coffees = Coffee.findAll();
    renderText(JsonParsers.coffee2Json(coffees));
  }
  
  public static void coffee (Long id)
  {
   Coffee coffee = Coffee.findById(id);
   renderJSON (JsonParsers.coffee2Json(coffee));
  }
  
  public static void createCoffee(JsonElement body)
  {
    Coffee coffee = JsonParsers.json2Coffee(body.toString());
    coffee.save();
    renderJSON (JsonParsers.coffee2Json(coffee));
  }  
}
