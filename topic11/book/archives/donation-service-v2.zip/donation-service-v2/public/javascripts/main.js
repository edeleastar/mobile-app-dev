$(document).ready(function()
{
  $('.ui.radio.checkbox')
    .checkbox()
  ;  
  $('.ui.dropdown')
    .dropdown({
      on: 'hover'
    })
  ;
})
;