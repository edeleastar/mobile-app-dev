package app.models;

public class Donation
{
  public Long   id;
  public int    amount;
  public String method;
  
  Donation()
  {}
  
  public Donation (int amount, String method)
  {
    this.amount = amount;
    this.method = method;
  }
  
  public String toString()
  {
    return amount + ", " + method;
  }
}
