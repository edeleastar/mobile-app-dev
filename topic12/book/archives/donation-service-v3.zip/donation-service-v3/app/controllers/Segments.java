package controllers;

import java.util.List;

import models.Donation;
import models.User;
import play.mvc.Controller;

public class Segments extends Controller
{
  public static void index()
  {
    User user = Accounts.getCurrentUser();
    List<Donation> donations = user.donations;
    render(donations);
  }
}
