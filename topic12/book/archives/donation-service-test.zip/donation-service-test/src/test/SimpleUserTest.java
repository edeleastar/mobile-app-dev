package test;

import static org.junit.Assert.*;
import java.util.ArrayList;
import java.util.List;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import app.models.DonationServiceAPI;
import app.models.User;

public class SimpleUserTest
{
  @Test
  public void testCreate () throws Exception
  {
    User homer = new User ("homer",  "simpson", "homer@simpson.com",  "secret");
    User user  = DonationServiceAPI.createUser(homer);
    assertEquals(homer, user);
    DonationServiceAPI.deleteUser(user);
  }

  @Test
  public void testGet () throws Exception
  {
    User homer = new User ("homer",  "simpson", "homer@simpson.com",  "secret");
    User user = DonationServiceAPI.createUser(homer);

    User searchUser = DonationServiceAPI.getUser(user.id);
    assertEquals (homer, searchUser);  
    DonationServiceAPI.deleteUser(user);
  }
  
  @Test
  public void testList () throws Exception
  {
    List<User> list1 = DonationServiceAPI.getUsers();
    
    User homer = new User ("homer",  "simpson", "homer@simpson.com",  "secret");
    User marge = new User ("marge",  "simpson", "homer@simpson.com",  "secret");
    User lisa  = new User ("lisa",  "simpson", "homer@simpson.com",  "secret");  
    
    User user1 = DonationServiceAPI.createUser(homer);
    User user2 = DonationServiceAPI.createUser(marge);
    User user3 = DonationServiceAPI.createUser(lisa);

    List<User> list2 = DonationServiceAPI.getUsers();
    assertEquals (list1.size()+3, list2.size());
    
    DonationServiceAPI.deleteUser(user1);
    DonationServiceAPI.deleteUser(user2);
    DonationServiceAPI.deleteUser(user3);

  }
}
